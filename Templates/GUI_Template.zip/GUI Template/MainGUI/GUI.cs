﻿using BepInEx;
using UnityEngine;
using Photon.Pun;
using Color = UnityEngine.Color;
using GorillaNetworking;
using System.IO;
using System.Net;
using AA;
using Photon.Realtime;
using ExitGames.Client.Photon;
using System.Collections;
using Hashtable = ExitGames.Client.Photon.Hashtable;
using System;
using Random = UnityEngine.Random;

namespace GUI_Template.MainGUI
{
    [BepInPlugin("Template.GUI", "GUI", "1.0")]
    public class MainGUI : BaseUnityPlugin
    {
        private int currentTab = 0;
        private void Update()
        {
            HandleBActions();
            HandleB2Actions();
            HandleB3Actions();
            HandleB4Actions();
        }
        private void HandleBActions()
        {
            if (B[1])
            {
                PhotonNetwork.JoinRoom(joinCode);
            }
            if (B[2])
            {
                PhotonNetwork.Disconnect();
            }
            if (B[3])
            {
                PhotonNetwork.JoinRandomRoom();
            }
        }
        private void HandleB2Actions()
        {
            if (B2[1])
            {
            }
            if (B2[2])
            {
            }
            if (B2[3])
            {
            }
            if (B2[4])
            {
            }
            if (B2[5])
            {
            }
            if (B2[6])
            {
            }
            if (B2[7])
            {
            }
            if (B2[8])
            {
            }
            if (B2[9])
            {
            }
        }
        private void HandleB3Actions()
        {
            if (B3[1])
            {
            }
            if (B3[2])
            {
                PlayerPrefs.SetString("tutorial", "nope");
                ExitGames.Client.Photon.Hashtable hashtable = new ExitGames.Client.Photon.Hashtable();
                hashtable.Add("didTutorial", false);
                PhotonNetwork.LocalPlayer.SetCustomProperties(hashtable);
                PlayerPrefs.Save();
            }
            if (B3[3])
            {
            }
            if (B3[4])
            {
            }
            if (B3[5])
            {
            }
            if (B3[6])
            {
            }
            if (B3[7])
            {
                guiEnabled = false;
            }
            if (B3[8])
            {
            }
        }
        private void HandleB4Actions()
        {
            if (B4[1])
            {
                PTTType("ALL CHAT");
                GorillaComputer.instance.pttType = "ALL CHAT";
            }
            if (B4[2])
            {
                PTTType("PUSH TO TALK");
                GorillaComputer.instance.pttType = "PUSH TO TALK";
            }
            if (B4[3])
            {
                PTTType("PUSH TO MUTE");
                GorillaComputer.instance.pttType = "PUSH TO MUTE";
            }
            if (B4[4])
            {
                foreach (PhotonView photonView in GameObject.Find("GorillaVRRigs").GetComponentsInChildren<PhotonView>())
                {
                    if (PhotonNetwork.InRoom)
                    {
                        SkinnedMeshRenderer componentInChildren2 = photonView.gameObject.GetComponentInChildren<SkinnedMeshRenderer>();
                        GorillaTagger.Instance.myVRRig.RPC("InitializeNoobMaterial", photonView.Controller, componentInChildren2.material.color.r, componentInChildren2.material.color.g, componentInChildren2.material.color.b, true);
                    }
                }
            }
            if (B4[5])
            {
                GameObject.Find("Global/GorillaParent/GorillaVRRigs/Gorilla Player Networked(Clone)").gameObject.SetActive(false);
                GameObject.Find("Global/GorillaParent/GorillaVRRigs/Gorilla Player Networked(Clone)").gameObject.SetActive(true);
                GameObject.Find("Global/GorillaParent/GorillaVRRigs/Gorilla Player Networked(Clone)").SetActive(false);
                PhotonNetwork.RemoveRPCs(PhotonNetwork.LocalPlayer);
            }
        }
        private void LoadImage()
        {
            string folderPath = "NIKO_Mods_Config";
            string filePath = Path.Combine(folderPath, "NIKO_Mod_GUI.png");
            string imageUrl = "https://cdn.discordapp.com/attachments/1121514533547151461/1124141579817455706/images.jpg";
            if (!Directory.Exists(folderPath))
            {
                Directory.CreateDirectory(folderPath);
            }
            if (!File.Exists(filePath))
            {
                using (WebClient client = new WebClient())
                {
                    client.DownloadFile(imageUrl, filePath);
                    byte[] imageBytes = File.ReadAllBytes(filePath);
                    Texture2D backgroundTexture = new Texture2D(2, 2);
                    backgroundTexture.LoadImage(imageBytes);
                    GUI.DrawTexture(new Rect(0, 0, Screen.width, Screen.height), backgroundTexture);
                }
            }
            if (File.Exists(filePath))
            {
                byte[] imageBytes = File.ReadAllBytes(filePath);
                Texture2D backgroundTexture = new Texture2D(2, 2);
                backgroundTexture.LoadImage(imageBytes);
                GUI.DrawTexture(new Rect(0, 0, Screen.width, Screen.height), backgroundTexture);
            }
        }
        private void DoMyWindow(int windowID)
        {
            if (backgroundTexture == null)
            {
                LoadImage();
            }

            GUI.DrawTexture(new Rect(0, 0, Screen.width, Screen.height), backgroundTexture);

            GUILayout.BeginHorizontal();

            DrawTabButton("Basic Mods", 0);
            DrawTabButton("Op Mods", 1);
            DrawTabButton("Mic Mods", 2);
            DrawTabButton("Self Mods", 3);
            DrawTabButton("Info", 4);

            GUILayout.EndHorizontal();

            switch (currentTab)
            {
                case 0:
                    BasicModsGUI();
                    break;
                case 1:
                    OpModsGUI();
                    break;
                case 2:
                    MicModsGUI();
                    break;
                case 3:
                    SelfModsGUI();
                    break;
                case 4:
                    InfoGUI();
                    break;
                default:
                    break;
            }
        }
        private void BasicModsGUI()
        {
            joinCode = GUI.TextField(new Rect(10, Spacing * 2, 75, 20), joinCode);
            B[1] = DrawToggles(Spacing * 3, B[1], "Join Code");
            B[2] = DrawToggles(Spacing * 4, B[2], "Disconnect");
            B[3] = DrawToggles(Spacing * 5, B[3], "Join Random Room");
        }
        private void OpModsGUI()
        {
            B2[1] = DrawToggles(Spacing * 2, B2[1], "");
            B2[2] = DrawToggle(Spacing * 3, B2[2], "");
            B2[3] = DrawToggle(Spacing * 4, B2[3], "");
            B2[4] = DrawToggle(Spacing * 5, B2[4], "");
            B2[5] = DrawToggle(Spacing * 6, B2[5], "");
            B2[6] = DrawToggle(Spacing * 7, B2[6], "");
            B2[7] = DrawToggle(Spacing * 8, B2[7], "");
            B2[8] = DrawToggle(Spacing * 9, B2[8], "");
            B2[9] = DrawToggle(Spacing * 10, B2[9], "");
        }
        private void MicModsGUI()
        {
            B3[1] = DrawToggle(Spacing * 2, B3[1], "");
            B3[2] = DrawToggles(Spacing * 3, B3[2], "No Tag On Join");
            B3[3] = DrawToggle(Spacing * 4, B3[3], "");
            B3[4] = DrawToggle(Spacing * 5, B3[4], "");
            B3[5] = DrawToggle(Spacing * 6, B3[5], "");
            B3[6] = DrawToggle(Spacing * 7, B3[6], "Destroy Menu");
            B3[7] = DrawToggle(Spacing * 8, B3[7], "Destroy GUI");
        }
        private void SelfModsGUI()
        {
            B4[1] = DrawToggles(Spacing * 2, B4[1], "All Chat");
            B4[2] = DrawToggles(Spacing * 3, B4[2], "Push To Talk");
            B4[3] = DrawToggles(Spacing * 4, B4[3], "Push To Mute");
            B4[4] = DrawToggles(Spacing * 5, B4[4], "See Color Codes");
            B4[5] = DrawToggles(Spacing * 6, B4[5], "Anti Crash");
        }
        private void InfoGUI()
        {
            deltaTime += (Time.deltaTime - deltaTime) * 0.1f;
            float f = 1f / deltaTime;
            DrawLabel(Spacing * 2, "Room Name: " + PhotonNetwork.CurrentRoom.Name);
            DrawLabel(Spacing * 3, "Name: " + PhotonNetwork.LocalPlayer.NickName);
            DrawLabel(Spacing * 4, "Ping: " + PhotonNetwork.GetPing().ToString());
            DrawLabel(Spacing * 5, "FPS: " + Mathf.Ceil(f).ToString());
            DrawLabel(Spacing * 6, "Players Online: " + PhotonNetworkController.Instance.TotalUsers().ToString());
            DrawLabel(Spacing * 7, "User ID: " + PhotonNetwork.LocalPlayer.UserId);
        }
        private bool DrawToggle(float yPosition, bool toggleState, string label)
        {
            GUI.backgroundColor = toggleState ? onColor : offColor;

            bool newToggleState = GUI.Toggle(new Rect(10, yPosition, ToggleWidth, ToggleHeight), toggleState, label);
            GUI.Label(new Rect(10 + ToggleWidth + 15, yPosition, LabelWidth, 20), newToggleState ? "On" : "Off");

            return newToggleState;
        }
        private bool DrawToggles(float yPosition, bool toggleState, string label)
        {
            GUI.backgroundColor = toggleState ? onColor : offColor;

            bool newToggleState = GUI.Toggle(new Rect(10, yPosition, ToggleWidth, ToggleHeight), toggleState, label);
            GUI.Label(new Rect(10 + ToggleWidth + 15, yPosition, LabelWidth, 20), newToggleState ? "On" : "Off");
            if (newToggleState && !toggleState)
            {
                StartCoroutine(ResetToggle(newToggleState, 0.3f));
            }

            return newToggleState;
        }
        private bool DrawToggleForRoom(float yPosition, bool toggleState, string label)
        {
            GUI.backgroundColor = toggleState ? onColor : offColor;

            bool newToggleState = GUI.Toggle(new Rect(100, yPosition, ToggleWidth, ToggleHeight), toggleState, label);

            return newToggleState;
        }
        private IEnumerator ResetToggle(bool currentToggleState, float delay)
        {
            yield return new WaitForSeconds(delay);
            int originalState = currentToggleState ? 1 : 0;
            int newToggleState = originalState ^ 1;
            bool finalToggleState = newToggleState == 1;
            B[1] = finalToggleState;
            B[2] = finalToggleState;
            B[3] = finalToggleState;
            B3[8] = finalToggleState;
        }
        private void DrawLabel(float yPosition, string labelText)
        {
            GUI.Label(new Rect(10, yPosition, 200, 50), labelText);
        }
        private void DrawTabButton(string label, int tabIndex)
        {
            if (currentTab == tabIndex)
                GUI.backgroundColor = activeTabColor;
            else
                GUI.backgroundColor = inactiveTabColor;

            if (GUILayout.Button(label))
            {
                currentTab = tabIndex;
            }
        }
        private void OnGUI()
        {
            if (guiEnabled)
            {
                GUI.Window(0, new Rect(20f, 20f, 350f, 300f), DoMyWindow, "Template GUI");
            }
        }
        private void PTTType(string type)
        {
            PlayerPrefs.SetString("pttType", type);
            GorillaComputer.instance.pttType = type;
            PlayerPrefs.Save();
        }
        public static VRRig FindVRRigForPlayer(Photon.Realtime.Player player)
        {
            foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
            {
                bool flag = !vrrig.isOfflineVRRig && vrrig.GetComponent<PhotonView>().Owner == player;
                if (flag)
                {
                    return vrrig;
                }
            }
            return null;
        }
        // Private Fields
        private Color onColor = Color.green;
        private Color offColor = Color.red;
        private Color activeTabColor = Color.green;
        private Color inactiveTabColor = Color.red;
        private const int ToggleWidth = 150;
        private const int ToggleHeight = 19;
        private const int LabelWidth = 50;
        private const int Spacing = 20;
        private bool[] B = new bool[99999];
        private bool[] B2 = new bool[99999];
        private bool[] B3 = new bool[99999];
        private bool[] B4 = new bool[99999];
        public float deltaTime;
        private bool imageLoaded = false;
        private bool guiEnabled = true;
        private string joinCode = "";
        private Texture2D backgroundTexture;
    }
    public class Utils : MonoBehaviour
    {
        private Color onColor = Color.green;
        private Color offColor = Color.red;
        private const int ToggleWidth = 150;
        private const int ToggleHeight = 30;
        private const int LabelWidth = 50;
        private const int Spacing = 20;
        private bool OnAndOffButton(float yPosition, bool toggleState, string label)
        {
            GUI.backgroundColor = toggleState ? onColor : offColor;

            if (GUI.Button(new Rect(10, yPosition, ToggleWidth, ToggleHeight), toggleState ? "On" : "Off"))
            {
                toggleState = !toggleState;
            }

            return toggleState;
        }
    }
}