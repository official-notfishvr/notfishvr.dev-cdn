﻿using BepInEx;
using UnityEngine;
using GUI_Template.MainGUI;

namespace GUI_Template.MainGUIUtils
{
    [BepInPlugin("ilovebigjucytomatos", "Kmaniscool", "1.6.9")]
    class BepInPatcher : BaseUnityPlugin
    {
        private static GameObject gameob = new GameObject();
        void Update()
        {
            if (!GameObject.Find("KmansBepInPatch"))
            {
                CreateBepInPatch();
                CreateInputPatch();
            }
        }
        public static void CreateInputPatch()
        {
            GameObject gameob = new GameObject();
            gameob.name = "KmansInputPatch";
            UnityEngine.Object.DontDestroyOnLoad(gameob);
        }
        public static void CreateBepInPatch()
        {
            Debug.Log("Creating Patcher");
            gameob.name = "KmansBepInPatch";
            gameob.AddComponent<ModMenuPatch>();
            gameob.AddComponent<ModMenuPatches>();
            gameob.AddComponent<MainGUI.MainGUI>();
            UnityEngine.Object.DontDestroyOnLoad(gameob);
            Debug.Log("Creating Patcher");
        }
    }
}
