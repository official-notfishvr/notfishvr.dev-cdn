using NIKO_Menu.MainMenu;
using System.Diagnostics;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

[assembly: AssemblyProduct("Menu Template")]
[assembly: AssemblyTitle("Menu Template")]
[assembly: AssemblyDescription("This Is Menu Template")]

[assembly: AssemblyCompany("Menu Template")]
[assembly: AssemblyCopyright("Copyright � 2023 Menu Template")]
[assembly: AssemblyConfiguration("Release")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: ComVisible(false)]
[assembly: AssemblyCulture("en-US")]
[assembly: NeutralResourcesLanguage("en-US")]
[assembly: AssemblyInformationalVersion("1.0")]
[assembly: AssemblyTrademark("Menu Template")]