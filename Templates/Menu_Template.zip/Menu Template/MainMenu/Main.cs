﻿using Debug = UnityEngine.Debug;
using Random = UnityEngine.Random;
using Color = UnityEngine.Color;
using Object = UnityEngine.Object;
using Hashtable = ExitGames.Client.Photon.Hashtable;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using ExitGames.Client.Photon;
using HarmonyLib;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine;
using UnityEngine.UI;
using Valve.VR;
using GorillaLocomotion.Gameplay;
using GorillaLocomotion.Swimming;
using System.Net;
using System.Diagnostics;
using GorillaNetworking;
using Photon.Voice.Unity;
using Photon.Voice.Unity.UtilityScripts;
using System.Collections;
using BepInEx;
using GorillaTag;
using System.Collections.Specialized;
using Newtonsoft.Json;
using System.ComponentModel;
using Menu_Temp.MainMenuPatches;
using System.Reflection;
using UnityEngine.InputSystem;
using Patches = Menu_Temp.MainMenuPatches.Patches;

namespace NIKO_Menu.MainMenu
{
    #region Loader
    [BepInPlugin("com.menutemp.menutemp", "menutemp", "1.0.0")]
    public class Loader : BaseUnityPlugin
    {
        public void FixedUpdate()
        {
            if (!GameObject.Find("Loader") && GorillaLocomotion.Player.hasInstance)
            {
                GameObject Loader = new GameObject("Loader");
                Loader.AddComponent<MenuPatch>();
                Loader.AddComponent<ControllerInput>();
                Loader.AddComponent<Patches>();
                Loader.AddComponent<NotifiLib>();
            }
        }
    }
    #endregion
    #region HarmonyPatch
    [BepInPlugin("menutemp.Menu", "menutemp.Menu", "1.0.0")]
    [Description("menutemp.Menu")]
    public class HarmonyPatch : BaseUnityPlugin
    {
        public void Awake()
        {
            Harmony harmony = new Harmony("menutemp.Menu");
            harmony.PatchAll(Assembly.GetExecutingAssembly());
        }
        private const string modGUID = "menutemp.Menu";
        private const string modName = "menutemp.Menu";
        public const string modVersion = "1.0.0";
    }
    #endregion
    #region MainMenu
    [HarmonyLib.HarmonyPatch(typeof(GorillaLocomotion.Player), "LateUpdate", MethodType.Normal)]
    public class MenuPatch : MonoBehaviour
    {
        #region MainButtons
        private static string[] buttons = new string[]
        {
            "Settings",                  // 0
            "Disconnect",                // 1
            "Join Random Room",          // 2
            "Fly",                       // 3
            "No Clip",                   // 4
            "Platform",                  // 5
            "Speed Boost",               // 6
            "Ghost Monkey",              // 7
            "Invs Monkey",               // 8
            "Beacons",                   // 9
            "ESP",                       // 10
            "Bone ESP",                  // 11
        };
        #endregion
        #region SettingsButtons
        private static string[] Settingsbuttons = new string[]
        {
            "Back",             // 0
            "Save Settings",    // 1
            "Load Settings",    // 2
            "ESP Color:",       // 3
            "Bone ESP Color:",  // 4
            "Fly Speed:",       // 5
            "Platforms Type:",  // 6
            "Platforms Color:"  // 7
        };
        #endregion
        #region buttonsActive
        private static bool[] buttonsActive = new bool[111]
{
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false
};
        public static bool[] SettingsButtonsActive = new bool[111]
    {
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false,
         false
    };
        #endregion
        #region Prefix
        private static void Prefix()
        {
            try
            {
                #region Menu
                SettingButtons();
                UpdateMaterialColors();
                if (once)
                {
                    MenuLoaded = true;
                    once = false;
                }
                if (init)
                {
                    // This Code Is Boken
                    init = false;
                    MainMenuRef = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    MainMenuRef.transform.parent = GorillaLocomotion.Player.Instance.rightControllerTransform;
                    string folderPath = "NIKO_Mods_Config";
                    if (!Directory.Exists(folderPath))
                    {
                        Directory.CreateDirectory(folderPath);
                    }
                    string filePath = Path.Combine(folderPath, "NIKO_Mod_Menu.png");
                    if (!File.Exists(filePath))
                    {
                        try
                        {
                            WebClient webClient = new WebClient();
                            webClient.DownloadFile("https://notfishvr6969.github.io/Image/NIKO_Mod_Menu.png", filePath);
                        }
                        catch (Exception e)
                        {
                            Debug.LogError("Image download error: " + e.Message);
                            return;
                        }
                    }
                    if (File.Exists(filePath))
                    {
                        try
                        {
                            Material material = new Material(Shader.Find("GorillaTag/UberShader"));
                            byte[] data = File.ReadAllBytes(filePath);
                            Texture2D menuTexture = new Texture2D(1, 1);
                            menuTexture.LoadImage(data);
                            material.mainTexture = menuTexture;
                            MainMenuRef.GetComponent<Renderer>().material = material;
                        }
                        catch (Exception e)
                        {
                            Debug.LogError("Texture loading error: " + e.Message);
                        }
                    }
                    else
                    {
                        Debug.LogError("Image file not found at: " + filePath);
                    }
                }
                GorillaLocomotion.Player __instance = GorillaLocomotion.Player.Instance;
                List<UnityEngine.XR.InputDevice> list = new List<UnityEngine.XR.InputDevice>();
                if (ControllerInputPoller.instance.leftControllerSecondaryButton)
                {
                    if (menu == null)
                    {
                        if (NumberForPage == "1")
                        {
                            Draw();
                        }
                        else
                        {
                            Draw2();
                        }
                        if (fingerButtonPresser == null)
                        {
                            fingerButtonPresser = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                            fingerButtonPresser.transform.SetParent(GorillaLocomotion.Player.Instance.rightControllerTransform);
                            fingerButtonPresser.name = "MenuClicker";
                            fingerButtonPresser.transform.localPosition = new Vector3(0f, -0.1f, 0f);
                            fingerButtonPresser.transform.localScale = new Vector3(0.01f, 0.01f, 0.01f);
                        }
                    }
                    menu.transform.position = GorillaLocomotion.Player.Instance.leftControllerTransform.position;
                    menu.transform.rotation = GorillaLocomotion.Player.Instance.leftControllerTransform.rotation;
                }
                else if (menu != null)
                {
                    Object.Destroy(menu);
                    menu = null;
                    Object.Destroy(fingerButtonPresser);
                    fingerButtonPresser = null;
                }
                #endregion
                #region buttonsActive
                if (buttonsActive[0] == true)
                {
                    NumberForPage = "2";
                    buttonsActive[0] = false;
                    Object.Destroy(menu);
                    menu = null;
                    Draw2();
                }
                if (buttonsActive[1] == true)
                {
                    PhotonNetwork.Disconnect();
                    NotifiLib.SendNotification("Your Have Been Disconnected", Color.green);
                    buttonsActive[1] = (bool)false;
                    UnityEngine.Object.Destroy(menu);
                    menu = null;
                    Draw();
                }
                if (buttonsActive[2] == true)
                {
                    PhotonNetwork.JoinRandomRoom();
                    NotifiLib.SendNotification("You Have Join Random Room", Color.green);
                    buttonsActive[2] = (bool)false;
                    UnityEngine.Object.Destroy(menu);
                    menu = null;
                    Draw();
                }
                if (buttonsActive[3] == true)
                {
                    Mods.MainStuff.BasicMods.Fly();
                    NotifiLib.SendNotification("Fly Is On", Color.green);
                }
                if (buttonsActive[4] == true)
                {
                    Mods.MainStuff.BasicMods.NoClip();
                    NotifiLib.SendNotification("No Clip Is On", Color.green);
                }
                if (buttonsActive[5] == true)
                {
                    Mods.MainStuff.BasicMods.PlatformMonke();
                    NotifiLib.SendNotification("Platforms Is On", Color.green);
                }
                if (buttonsActive[6] == true)
                {
                    Mods.MainStuff.BasicMods.SpeedBoost();
                    NotifiLib.SendNotification("Speed Boost Is On", Color.green);
                }
                if (buttonsActive[7] == true)
                {
                    Mods.MainStuff.BasicMods.GhostMonkey();
                    NotifiLib.SendNotification("Ghost Monkey Is On", Color.green);
                }
                if (buttonsActive[8] == true)
                {
                    Mods.MainStuff.BasicMods.InvsMonkey();
                    NotifiLib.SendNotification("Invs Monkey Is On", Color.green);
                }
                if (buttonsActive[9] == true)
                {
                    Mods.MainStuff.BasicMods.Beacons();
                    NotifiLib.SendNotification("Beacons Is On", Color.green);
                }
                if (buttonsActive[10] == true)
                {
                    Mods.MainStuff.BasicMods.ESP(true);
                    NotifiLib.SendNotification("ESP Is On", Color.green);
                }
                else
                {
                    Mods.MainStuff.BasicMods.ESP(false);
                }
                if (buttonsActive[11] == true)
                {
                    Mods.MainStuff.BasicMods.BoneESP();
                    noesp = true;
                    NotifiLib.SendNotification("Bone ESP Is On", Color.green);
                }
                else if (noesp)
                {
                    foreach (VRRig vrrig4 in GorillaParent.instance.vrrigs)
                    {
                        for (int num63 = 0; num63 < Enumerable.Count<int>(bones); num63 += 2)
                        {
                            if (vrrig4 != null)
                            {
                                if (vrrig4.mainSkin.bones[bones[num63]].gameObject.GetComponent<LineRenderer>())
                                {
                                    UnityEngine.Object.Destroy(vrrig4.mainSkin.bones[bones[num63]].gameObject.GetComponent<LineRenderer>());
                                }
                                if (vrrig4.head.rigTarget.gameObject.GetComponent<LineRenderer>())
                                {
                                    UnityEngine.Object.Destroy(vrrig4.head.rigTarget.gameObject.GetComponent<LineRenderer>());
                                }
                            }
                        }
                    }
                    noesp = false;
                }
                #endregion
            }
            catch (Exception ex)
            {
                Mods.Utils.LogError(ex);
            }
        }
        #endregion
        #region Mods
        public class Mods : MonoBehaviour
        {
            public class MainStuff
            {
                public class OpMods
                {
                }
                public class BasicMods
                {
                    public static void WallWalk()
                    {
                        if (ControllerInput.RightGrip)
                        {
                            RaycastHit hit;
                            if (Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position, GorillaLocomotion.Player.Instance.rightControllerTransform.right, out hit, 100f, 512) && hit.distance < 2f)
                            {
                                Rigidbody body = GorillaLocomotion.Player.Instance.bodyCollider.attachedRigidbody;
                                body.useGravity = false;
                                body.velocity -= hit.normal * (15f * Time.deltaTime);
                            }
                            GorillaLocomotion.Player.Instance.bodyCollider.attachedRigidbody.useGravity = true;
                        }
                    }
                    public static void Matthing()
                    {
                        if (GorillaTagger.Instance.offlineVRRig != null && GorillaTagger.Instance.offlineVRRig.enabled)
                        {
                            if (GorillaGameManager.instance != null)
                            {
                                GorillaTagger.Instance.offlineVRRig.ChangeMaterialLocal(GorillaGameManager.instance.MyMatIndex(PhotonNetwork.LocalPlayer));
                            }
                            else
                            {
                                GorillaTagger.Instance.offlineVRRig.ChangeMaterialLocal(0);
                            }
                        }
                    }
                    public static void InvsMonkey()
                    {
                        if (ControllerInput.RightTrigger)
                        {
                            if (!ghostToggled && GorillaTagger.Instance.offlineVRRig.enabled)
                            {
                                Patches.UpdateLine.Override = false;
                                if (GorillaTagger.Instance.offlineVRRig.enabled)
                                {
                                    Patches.VRRigOnDisable.Prefix(GorillaTagger.Instance.offlineVRRig);
                                }
                                GorillaTagger.Instance.offlineVRRig.enabled = false;
                                GorillaTagger.Instance.offlineVRRig.transform.position = new Vector3(999f, 999f, 999f);
                                ghostToggled = true;
                            }
                            else
                            {
                                if (!ghostToggled && !GorillaTagger.Instance.offlineVRRig.enabled)
                                {
                                    Patches.UpdateLine.Override = true;
                                    GorillaTagger.Instance.offlineVRRig.enabled = true;
                                    Matthing();
                                    ghostToggled = true;
                                }
                            }
                        }
                        else
                        {
                            ghostToggled = false;
                        }
                    }
                    public static void GhostMonkey()
                    {
                        if (ControllerInput.RightTrigger)
                        {
                            if (!ghostToggled && GorillaTagger.Instance.offlineVRRig.enabled)
                            {
                                Patches.UpdateLine.Override = false;
                                if (GorillaTagger.Instance.offlineVRRig.enabled)
                                {
                                    Patches.VRRigOnDisable.Prefix(GorillaTagger.Instance.offlineVRRig);
                                }
                                GorillaTagger.Instance.offlineVRRig.enabled = false;
                                ghostToggled = true;
                            }
                            else
                            {
                                if (!ghostToggled && !GorillaTagger.Instance.offlineVRRig.enabled)
                                {
                                    Patches.UpdateLine.Override = true;
                                    GorillaTagger.Instance.offlineVRRig.enabled = true;
                                    Matthing();
                                    ghostToggled = true;
                                }
                            }
                        }
                        else
                        {
                            ghostToggled = false;
                        }
                    }
                    public static void SpeedBoost()
                    {
                        if (PhotonNetwork.InRoom)
                        {
                            GorillaGameManager gameManager = GorillaGameManager.instance;
                            GorillaLocomotion.Player player = GorillaLocomotion.Player.Instance;


                            player.maxJumpSpeed = gameManager.fastJumpLimit;
                            player.jumpMultiplier = gameManager.fastJumpMultiplier;

                            gameManager.fastJumpLimit = 8.5f;
                            gameManager.fastJumpMultiplier = 1.2f;
                        }
                    }
                    public static void PlatformMonke()
                    {
                        if (plattype == 0f)
                        {
                            jump_right_local = GameObject.CreatePrimitive(PrimitiveType.Cube);
                            jump_left_local = GameObject.CreatePrimitive(PrimitiveType.Cube);
                        }
                        if (plattype == 1f)
                        {
                            jump_right_local = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                            jump_left_local = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        }
                        if (plattype == 2f)
                        {
                            jump_right_local = GameObject.CreatePrimitive(PrimitiveType.Capsule);
                            jump_left_local = GameObject.CreatePrimitive(PrimitiveType.Capsule);
                        }
                        if (plattype == 3f)
                        {
                            jump_right_local = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
                            jump_left_local = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
                        }
                        if (plattype == 4f)
                        {
                            jump_right_local = GameObject.CreatePrimitive(PrimitiveType.Plane);
                            jump_left_local = GameObject.CreatePrimitive(PrimitiveType.Plane);
                        }
                        if (plattype == 5f)
                        {
                            jump_right_local = GameObject.CreatePrimitive(PrimitiveType.Quad);
                            jump_left_local = GameObject.CreatePrimitive(PrimitiveType.Quad);
                        }
                        if (!once_networking)
                        {
                            PhotonNetwork.NetworkingClient.EventReceived += PlatformNetwork;
                            once_networking = true;
                        }
                        if (ControllerInput.RightGrip)
                        {
                            if (!once_right && jump_right_local == null)
                            {
                                jump_right_local.GetComponent<Renderer>().material.SetColor("_Color", Platcolor);
                                jump_right_local.transform.localScale = scale;
                                jump_right_local.transform.position = new Vector3(0f, -0.0075f, 0f) + GorillaLocomotion.Player.Instance.rightControllerTransform.position;
                                jump_right_local.transform.rotation = GorillaLocomotion.Player.Instance.rightControllerTransform.rotation;
                                object[] eventContent = { GorillaLocomotion.Player.Instance.leftControllerTransform.position, GorillaLocomotion.Player.Instance.leftControllerTransform.rotation };
                                RaiseEventOptions raiseEventOptions = new RaiseEventOptions { Receivers = ReceiverGroup.Others };
                                PhotonNetwork.RaiseEvent(70, eventContent, raiseEventOptions, SendOptions.SendReliable);
                                once_right = true;
                                once_right_false = false;
                            }
                        }
                        else if (!once_right_false && jump_right_local != null)
                        {
                            UnityEngine.Object.Destroy(jump_right_local);
                            jump_right_local = null;
                            once_right = false;
                            once_right_false = true;
                            RaiseEventOptions raiseEventOptions2 = new RaiseEventOptions { Receivers = ReceiverGroup.Others };
                            PhotonNetwork.RaiseEvent(72, null, raiseEventOptions2, SendOptions.SendReliable);
                        }
                        if (ControllerInput.LeftGrip)
                        {
                            if (!once_left && jump_left_local == null)
                            {
                                jump_left_local.GetComponent<Renderer>().material.SetColor("_Color", Platcolor);
                                jump_left_local.transform.localScale = scale;
                                jump_left_local.transform.position = GorillaLocomotion.Player.Instance.leftControllerTransform.position;
                                jump_left_local.transform.rotation = GorillaLocomotion.Player.Instance.leftControllerTransform.rotation;
                                object[] eventContent2 = { GorillaLocomotion.Player.Instance.leftControllerTransform.position, GorillaLocomotion.Player.Instance.leftControllerTransform.rotation };
                                RaiseEventOptions raiseEventOptions3 = new RaiseEventOptions { Receivers = ReceiverGroup.Others };
                                PhotonNetwork.RaiseEvent(69, eventContent2, raiseEventOptions3, SendOptions.SendReliable);
                                once_left = true;
                                once_left_false = false;
                            }
                        }
                        else if (!once_left_false && jump_left_local != null)
                        {
                            UnityEngine.Object.Destroy(jump_left_local);
                            jump_left_local = null;
                            once_left = false;
                            once_left_false = true;
                            RaiseEventOptions raiseEventOptions4 = new RaiseEventOptions { Receivers = ReceiverGroup.Others };
                            PhotonNetwork.RaiseEvent(71, null, raiseEventOptions4, SendOptions.SendReliable);
                        }
                        if (!PhotonNetwork.InRoom)
                        {
                            for (int i = 0; i < jump_right_network.Length; i++)
                            {
                                UnityEngine.Object.Destroy(jump_right_network[i]);
                            }
                            for (int j = 0; j < jump_left_network.Length; j++)
                            {
                                UnityEngine.Object.Destroy(jump_left_network[j]);
                            }
                        }
                    }
                    public static void Fly()
                    {
                        GorillaLocomotion.Player player = GorillaLocomotion.Player.Instance;
                        Rigidbody playerRigidbody = player.GetComponent<Rigidbody>();
                        Vector3 flyDirection = player.headCollider.transform.forward;
                        if (!ControllerInput.RightTrigger)
                        {
                            if (flying)
                            {
                                playerRigidbody.velocity = flyDirection * Time.deltaTime * FlySpeed;
                                flying = false;
                            }
                        }
                        else
                        {
                            player.transform.position += flyDirection * FlySpeed;
                            playerRigidbody.velocity = Vector3.zero;
                            if (!flying)
                            {
                                flying = true;
                            }
                        }
                    }
                    public static void NoClip()
                    {
                        if (ControllerInput.RightTrigger)
                        {
                            MeshCollider[] meshColliders = Resources.FindObjectsOfTypeAll<MeshCollider>();
                            foreach (MeshCollider collider in meshColliders)
                            {
                                collider.enabled = false;
                            }
                        }
                        else
                        {
                            MeshCollider[] meshColliders = Resources.FindObjectsOfTypeAll<MeshCollider>();
                            foreach (MeshCollider collider in meshColliders)
                            {
                                collider.enabled = true;
                            }
                        }
                    }
                    public static void TrampolineBoost()
                    {
                        GorillaSurfaceOverride[] surfaceOverrides = UnityEngine.GameObject.FindObjectsOfType<GorillaSurfaceOverride>();
                        foreach (var surfaceOverride in surfaceOverrides)
                        {
                            if (surfaceOverride.name == "BounceyTop")
                            {
                                surfaceOverride.extraVelMultiplier = 10f;
                                surfaceOverride.extraVelMaxMultiplier = 12f;
                            }
                        }
                    }
                    public static void Beacons()
                    {
                        if (PhotonNetwork.CurrentRoom != null)
                        {
                            foreach (Photon.Realtime.Player player3 in PhotonNetwork.PlayerListOthers)
                            {
                                PhotonView photonView3 = GorillaGameManager.instance.FindVRRigForPlayer(player3);
                                VRRig vrrig = GorillaGameManager.instance.FindPlayerVRRig(player3);
                                if (!vrrig.isOfflineVRRig && !vrrig.isMyPlayer && !photonView3.IsMine)
                                {
                                    GameObject gameObject = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
                                    UnityEngine.Object.Destroy(gameObject.GetComponent<BoxCollider>());
                                    UnityEngine.Object.Destroy(gameObject.GetComponent<Rigidbody>());
                                    UnityEngine.Object.Destroy(gameObject.GetComponent<Collider>());
                                    gameObject.GetComponent<MeshRenderer>().material.SetColor("_Color", Color.green);
                                    gameObject.transform.rotation = Quaternion.identity;
                                    gameObject.transform.localScale = new Vector3(0.04f, 200f, 0.04f);
                                    gameObject.transform.position = vrrig.transform.position;
                                    gameObject.GetComponent<MeshRenderer>().material = vrrig.mainSkin.material;
                                    UnityEngine.Object.Destroy(gameObject, Time.deltaTime);
                                }
                            }
                        }
                    }
                    public static void ESP(bool enable)
                    {
                        foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                        {
                            if (ESpInt == 0)
                            {
                                if (!vrrig.isOfflineVRRig && !vrrig.isMyPlayer && vrrig.mainSkin.material.name.Contains("fected"))
                                {
                                    vrrig.mainSkin.material.shader = Shader.Find("GUI/Text Shader");
                                    vrrig.mainSkin.material.color = new Color(9f, 0f, 0f);
                                }
                                else if (!vrrig.isOfflineVRRig && !vrrig.isMyPlayer)
                                {
                                    vrrig.mainSkin.material.shader = Shader.Find("GUI/Text Shader");
                                    vrrig.mainSkin.material.color = new Color(0f, 9f, 0f);
                                }
                            }
                            else if (!vrrig.isOfflineVRRig && !vrrig.isMyPlayer)
                            {
                                vrrig.mainSkin.material.shader = Shader.Find("GUI/Text Shader");
                                vrrig.mainSkin.material.color = ESPColor;
                            }
                            else if (enable == false)
                            {
                                if (!vrrig.isOfflineVRRig && !vrrig.isMyPlayer)
                                {
                                    vrrig.ChangeMaterialLocal(vrrig.currentMatIndex);
                                }
                            }
                            else
                            {
                                if (!vrrig.isOfflineVRRig && !vrrig.isMyPlayer)
                                {
                                    vrrig.ChangeMaterialLocal(vrrig.currentMatIndex);
                                }
                            }
                        }
                    }
                    public static void BoneESP()
                    {
                        foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                        {
                            if (!vrrig.isOfflineVRRig && !vrrig.isMyPlayer)
                            {
                                if (vrrig != null)
                                {
                                    Material material2 = new Material(Shader.Find("GUI/Text Shader"));
                                    material2.color = Color.green;
                                    if (!vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>())
                                    {
                                        vrrig.head.rigTarget.gameObject.AddComponent<LineRenderer>();
                                    }
                                    vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().endWidth = 0.015f;
                                    vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().startWidth = 0.015f;
                                    vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().material = material2;
                                    vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().SetPosition(0, vrrig.head.rigTarget.transform.position + new Vector3(0f, 0.16f, 0f));
                                    vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().SetPosition(1, vrrig.head.rigTarget.transform.position - new Vector3(0f, 0.4f, 0f));
                                    for (int j = 0; j < Enumerable.Count<int>(bones); j += 2)
                                    {
                                        if (!vrrig.mainSkin.bones[bones[j]].gameObject.GetComponent<LineRenderer>())
                                        {
                                            vrrig.mainSkin.bones[bones[j]].gameObject.AddComponent<LineRenderer>();
                                        }
                                        vrrig.mainSkin.bones[bones[j]].gameObject.GetComponent<LineRenderer>().endWidth = 0.015f;
                                        vrrig.mainSkin.bones[bones[j]].gameObject.GetComponent<LineRenderer>().startWidth = 0.015f;
                                        vrrig.mainSkin.bones[bones[j]].gameObject.GetComponent<LineRenderer>().material = material2;
                                        vrrig.mainSkin.bones[bones[j]].gameObject.GetComponent<LineRenderer>().SetPosition(0, vrrig.mainSkin.bones[bones[j]].position);
                                        vrrig.mainSkin.bones[bones[j]].gameObject.GetComponent<LineRenderer>().SetPosition(1, vrrig.mainSkin.bones[bones[j + 1]].position);
                                    }
                                }
                            }
                            else
                            {
                                Material material3 = new Material(Shader.Find("GUI/Text Shader"));
                                material3.color = BoneESPColor;
                                if (!vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>())
                                {
                                    vrrig.head.rigTarget.gameObject.AddComponent<LineRenderer>();
                                }
                                vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().endWidth = 0.015f;
                                vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().startWidth = 0.015f;
                                vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().material = material3;
                                vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().SetPosition(0, vrrig.head.rigTarget.transform.position + new Vector3(0f, 0.16f, 0f));
                                vrrig.head.rigTarget.gameObject.GetComponent<LineRenderer>().SetPosition(1, vrrig.head.rigTarget.transform.position - new Vector3(0f, 0.4f, 0f));
                                for (int k = 0; k < Enumerable.Count<int>(bones); k += 2)
                                {
                                    if (!vrrig.mainSkin.bones[bones[k]].gameObject.GetComponent<LineRenderer>())
                                    {
                                        vrrig.mainSkin.bones[bones[k]].gameObject.AddComponent<LineRenderer>();
                                    }
                                    vrrig.mainSkin.bones[bones[k]].gameObject.GetComponent<LineRenderer>().endWidth = 0.015f;
                                    vrrig.mainSkin.bones[bones[k]].gameObject.GetComponent<LineRenderer>().startWidth = 0.015f;
                                    vrrig.mainSkin.bones[bones[k]].gameObject.GetComponent<LineRenderer>().material = material3;
                                    vrrig.mainSkin.bones[bones[k]].gameObject.GetComponent<LineRenderer>().SetPosition(0, vrrig.mainSkin.bones[bones[k]].position);
                                    vrrig.mainSkin.bones[bones[k]].gameObject.GetComponent<LineRenderer>().SetPosition(1, vrrig.mainSkin.bones[bones[k + 1]].position);
                                }
                            }
                        }
                    }
                    public static void FixGunCode()
                    {
                        if (ControllerInput.RightGrip)
                        {
                            RaycastHit raycastHit;
                            if (Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position - GorillaLocomotion.Player.Instance.rightControllerTransform.up, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out raycastHit) && pointer == null)
                            {
                                pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                                UnityEngine.Object.Destroy(pointer.GetComponent<Rigidbody>());
                                UnityEngine.Object.Destroy(pointer.GetComponent<SphereCollider>());
                                pointer.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
                                pointer.GetComponent<Renderer>().material.color = Color.red;
                            }
                            pointer.transform.position = raycastHit.point;
                            PhotonView Photonview = rig2view(raycastHit.collider.GetComponentInParent<VRRig>());
                            Photon.Realtime.Player owner = Photonview.Owner;
                            if (ControllerInput.RightTrigger)
                            {

                            }
                            else
                            {
                                pointer.GetComponent<Renderer>().material.color = Color.red;
                            }
                            return;
                        }
                        UnityEngine.GameObject.Destroy(pointer);
                    }
                }
            }
            public class Utils
            {
                public static void LogError(Exception ex)
                {
                    string logDirectory = "Menu_Temp_Error";
                    Directory.CreateDirectory(logDirectory);

                    string errorMessage = $"Error Message: {ex.Message}";
                    string stackTrace = $"Error occurred on Line: {ex.StackTrace}";
                    string logFileName = Path.Combine(logDirectory, $"Menu_Temp_error_{DateTime.Now:yyyy_MM_dd_HHmm_ss}.log");

                    //Debug.LogError("Menu had an error");
                    //Debug.LogError(stackTrace);
                    //Debug.LogError(errorMessage);

                    File.WriteAllText(logFileName, ex.ToString());
                }
            }
        }
        #endregion
        #region Utils
        public static void SettingButtons()
        {
            // ESP Color
            string[] colorNames = { "Tag", "Black", "Red", "Blue", "Yellow", "Green", "Purple", "White" };
            int[] espcolorIndices = { 0, 1, 2, 3, 4, 5, 6, 7 };
            int espnumColors = espcolorIndices.Length;
            int espcurrentColorIndex = ESpInt;
            Settingsbuttons[3] = "ESP Color: " + colorNames[espcurrentColorIndex];

            // Bone ESP Color
            string[] BonecolorNames = { "Tag", "Black", "Red", "Blue", "Yellow", "Green", "Purple", "White" };
            int[] BoneespcolorIndices = { 0, 1, 2, 3, 4, 5, 6, 7 };
            int BoneespnumColors = BoneespcolorIndices.Length;
            int BoneespcurrentColorIndex = BoneESpInt;
            Settingsbuttons[4] = "Bone ESP Color: " + BonecolorNames[BoneespcurrentColorIndex];

            // Fly Speed
            string[] flySpeedNames = { "Super Slow", "Slow", "Normal", "Fast", "Super Fast" };
            float[] flyIndices = { 0, 1, 2, 3, 4 };
            int flySpeedCount = flyIndices.Length;
            int currentFlySpeedIndex = SpeedCount;
            Settingsbuttons[5] = "Fly Speed: " + flySpeedNames[currentFlySpeedIndex];

            // Platforms Type
            string[] PlatformsTypeNames = { "Normal", "Sticky", "Capsule", "Cylinder", "Plane", "Quad" };
            float[] PlatformsTypeIndices = { 0, 1, 2, 3, 4, 5 };
            int PlatformsTypeSpeedCount = PlatformsTypeIndices.Length;
            int currentPlatformsTypeIndex = platCountType;
            Settingsbuttons[6] = "Platforms Type: " + PlatformsTypeNames[currentPlatformsTypeIndex];

            // Platforms Color
            string[] PlatformscolorNames = { "Black", "Red", "Blue", "Yellow", "Green", "Purple", "White" };
            int[] PlatformsespcolorIndices = { 0, 1, 2, 3, 4, 5, 6 };
            int PlatformsespnumColors = PlatformsespcolorIndices.Length;
            int PlatformsespcurrentColorIndex = platCountColor;
            Settingsbuttons[7] = "Platforms Color: " + PlatformscolorNames[PlatformsespcurrentColorIndex];

            if (SettingsButtonsActive[3] == true)
            {
                espcurrentColorIndex = (espcurrentColorIndex + 1) % espnumColors;
                ESpInt = espcurrentColorIndex;
                Settingsbuttons[3] = "ESP Color: " + colorNames[espcurrentColorIndex];
                Color[] colors = { Color.clear, Color.black, Color.red, Color.blue, Color.yellow, Color.green, Color.magenta, Color.white };
                ESPColor = colors[espcurrentColorIndex];
                SettingsButtonsActive[3] = false;
                UnityEngine.Object.Destroy(menu);
                menu = null;
                Draw2();
            }
            if (SettingsButtonsActive[4] == true)
            {
                BoneespcurrentColorIndex = (BoneespcurrentColorIndex + 1) % BoneespnumColors;
                BoneESpInt = BoneespcurrentColorIndex;
                Settingsbuttons[4] = "Bone ESP Color: " + BonecolorNames[BoneespcurrentColorIndex];
                Color[] Bonecolors = { Color.clear, Color.black, Color.red, Color.blue, Color.yellow, Color.green, Color.magenta, Color.white };
                ESPColor = Bonecolors[BoneespcurrentColorIndex];
                SettingsButtonsActive[4] = false;
                UnityEngine.Object.Destroy(menu);
                menu = null;
                Draw2();
            }
            if (SettingsButtonsActive[5] == true)
            {
                currentFlySpeedIndex = (currentFlySpeedIndex + 1) % flySpeedCount;
                SpeedCount = currentFlySpeedIndex;
                Settingsbuttons[5] = "Fly Speed: " + flySpeedNames[currentFlySpeedIndex];
                float[] FlySpeedf = { 0.1f, 5f, 15f, 30f, 150f };
                FlySpeed = FlySpeedf[currentFlySpeedIndex];
                SettingsButtonsActive[5] = false;
                UnityEngine.Object.Destroy(menu);
                menu = null;
                Draw2();
            }
            if (SettingsButtonsActive[6] == true)
            {
                currentPlatformsTypeIndex = (currentPlatformsTypeIndex + 1) % PlatformsTypeSpeedCount;
                platCountType = currentPlatformsTypeIndex;
                Settingsbuttons[6] = "Platforms Type: " + PlatformsTypeNames[currentPlatformsTypeIndex];
                float[] Platformsf = { 0f, 1f, 2f, 3f, 4f, 5f };
                plattype = Platformsf[currentPlatformsTypeIndex];
                SettingsButtonsActive[6] = false;
                UnityEngine.Object.Destroy(menu);
                menu = null;
                Draw2();
            }
            if (SettingsButtonsActive[7] == true)
            {
                PlatformsespcurrentColorIndex = (PlatformsespcurrentColorIndex + 1) % PlatformsespnumColors;
                platCountColor = PlatformsespcurrentColorIndex;
                Settingsbuttons[7] = "Platforms Color: " + PlatformscolorNames[PlatformsespcurrentColorIndex];
                Color[] platcolors = { Color.black, Color.red, Color.blue, Color.yellow, Color.green, Color.magenta, Color.white };
                Platcolor = platcolors[PlatformsespcurrentColorIndex];
                SettingsButtonsActive[7] = false;
                UnityEngine.Object.Destroy(menu);
                menu = null;
                Draw2();
            }
            if (SettingsButtonsActive[0] == true)
            {
                SettingsButtonsActive[0] = (bool)false;
                UnityEngine.Object.Destroy(menu);
                menu = null;
                Draw();
                NumberForPage = "1";
                MainPageOn = true;
                SettingsPageOn = false;
            }
            if (SettingsButtonsActive[1] == true)
            {
                // REMOVED
                SettingsButtonsActive[1] = (bool)false;
                UnityEngine.Object.Destroy(menu);
                menu = null;
                Draw2();
                SettingsPageOn = true;
            }
            if (SettingsButtonsActive[2] == true)
            {
                // REMOVED
                SettingsButtonsActive[2] = (bool)false;
                UnityEngine.Object.Destroy(menu);
                menu = null;
                Draw2();
                SettingsPageOn = true;
            }
        }
        public static void UpdateMaterialColors()
        {
            MenuColor.mainTexture = menutexture;
            BtnDisabledColor.color = Color.black;
            BtnEnabledColor.color = Color.blue;
            Next.color = Color.grey;
            Previous.color = Color.grey;
        }
        public static PhotonView rig2view(VRRig vrrig)
        {
            return Traverse.Create(vrrig).Field("photonView").GetValue<PhotonView>();
        }
        #endregion
        #region Main Menu
        private static void PlatformNetwork(EventData eventData)
        {
            byte code = eventData.Code;
            if (code == 69)
            {
                object[] array = (object[])eventData.CustomData;
                jump_left_network[eventData.Sender] = GameObject.CreatePrimitive(PrimitiveType.Cube);
                jump_left_network[eventData.Sender].GetComponent<Renderer>().material.SetColor("_Color", Platcolor);
                jump_left_network[eventData.Sender].transform.localScale = scale;
                jump_left_network[eventData.Sender].transform.position = (Vector3)array[0];
                jump_left_network[eventData.Sender].transform.rotation = (Quaternion)array[1];
                return;
            }
            if (code == 70)
            {
                object[] array2 = (object[])eventData.CustomData;
                jump_right_network[eventData.Sender] = GameObject.CreatePrimitive(PrimitiveType.Cube);
                jump_right_network[eventData.Sender].GetComponent<Renderer>().material.SetColor("_Color", Platcolor);
                jump_right_network[eventData.Sender].transform.localScale = scale;
                jump_right_network[eventData.Sender].transform.position = (Vector3)array2[0];
                jump_right_network[eventData.Sender].transform.rotation = (Quaternion)array2[1];
                return;
            }
            if (code == 71)
            {
                UnityEngine.Object.Destroy(jump_left_network[eventData.Sender]);
                jump_left_network[eventData.Sender] = null;
                return;
            }
            if (code == 72)
            {
                UnityEngine.Object.Destroy(jump_right_network[eventData.Sender]);
                jump_right_network[eventData.Sender] = null;
            }
        }
        #region Draw
        private static void AddButton(float offset, string text)
        {
            GameObject gameObject = GameObject.CreatePrimitive(PrimitiveType.Cube);
            UnityEngine.Object.Destroy(gameObject.GetComponent<Rigidbody>());
            gameObject.GetComponent<BoxCollider>().isTrigger = true;
            gameObject.transform.parent = menu.transform;
            gameObject.transform.rotation = Quaternion.identity;
            gameObject.transform.localScale = new Vector3(0.09f, 0.8f, 0.08f);
            gameObject.transform.localPosition = new Vector3(0.56f, 0f, 0.58f - offset);
            gameObject.AddComponent<BtnCollider>().relatedText = text;
            gameObject.name = text;

            int num = -1;

            for (int i = 0; i < buttons.Length; i++)
            {
                if (text == buttons[i])
                {
                    num = i;
                    break;
                }
            }

            if (buttonsActive[num] == false)
            {
                gameObject.GetComponent<Renderer>().material.color = Color.black;
            }
            else
            {
                gameObject.GetComponent<Renderer>().material.color = Color.red;
            }

            GameObject gameObject2 = new GameObject();
            gameObject2.transform.parent = canvasObj.transform;

            Text text2 = gameObject2.AddComponent<Text>();
            text2.font = Resources.GetBuiltinResource(typeof(Font), "Arial.ttf") as Font;
            text2.text = text;
            text2.fontSize = 1;
            text2.fontStyle = FontStyle.Italic;
            text2.alignment = TextAnchor.MiddleCenter;
            text2.resizeTextForBestFit = true;
            text2.resizeTextMinSize = 0;

            RectTransform component = text2.GetComponent<RectTransform>();
            component.localPosition = Vector3.zero;
            component.sizeDelta = new Vector2(0.2f, 0.03f);
            component.localPosition = new Vector3(0.064f, 0f, 0.231f - offset / 2.55f);
            component.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
        }
        public static void Draw()
        {
            NumberForPage = "1";

            menu = GameObject.CreatePrimitive(PrimitiveType.Cube);
            UnityEngine.Object.Destroy(menu.GetComponent<Rigidbody>());
            UnityEngine.Object.Destroy(menu.GetComponent<BoxCollider>());
            UnityEngine.Object.Destroy(menu.GetComponent<Renderer>());
            menu.transform.localScale = new Vector3(0.1f, 0.3f, 0.4f);
            menu.name = "Menu";

            GameObject gameObject = GameObject.CreatePrimitive(PrimitiveType.Cube);
            UnityEngine.Object.Destroy(gameObject.GetComponent<Rigidbody>());
            UnityEngine.Object.Destroy(gameObject.GetComponent<BoxCollider>());
            gameObject.transform.parent = menu.transform;
            gameObject.transform.rotation = Quaternion.identity;
            gameObject.transform.localScale = new Vector3(0.1f, 0.94f, 1.2f);
            gameObject.name = "Menucolor";
            gameObject.transform.position = new Vector3(0.05f, 0f, -0.03f);
            canvasObj = new GameObject();
            canvasObj.transform.parent = menu.transform;
            canvasObj.name = "canvas";
            Canvas canvas = canvasObj.AddComponent<Canvas>();
            CanvasScaler canvasScaler = canvasObj.AddComponent<CanvasScaler>();
            canvasObj.AddComponent<GraphicRaycaster>();
            canvas.renderMode = RenderMode.WorldSpace;
            canvasScaler.dynamicPixelsPerUnit = 1000f;

            GameObject gameObject2 = new GameObject();
            gameObject2.transform.parent = canvasObj.transform;
            gameObject2.name = "Title";
            Text text = gameObject2.AddComponent<Text>();
            text.font = Resources.GetBuiltinResource(typeof(Font), "Arial.ttf") as Font;
            text.text = "Menu Temp";
            text.fontSize = 1;
            text.fontStyle = FontStyle.Italic;
            text.alignment = TextAnchor.MiddleCenter;
            text.resizeTextForBestFit = true;
            text.resizeTextMinSize = 0;
            RectTransform component = text.GetComponent<RectTransform>();
            component.localPosition = Vector3.zero;
            component.sizeDelta = new Vector2(0.28f, 0.05f);
            component.position = new Vector3(0.06f, 0f, 0.175f);
            component.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));

            AddPageButtons();
            string[] array2 = buttons.Skip(pageNumber * pageSize).Take(pageSize).ToArray();
            for (int i = 0; i < array2.Length; i++)
            {
                AddButton((float)i * 0.13f + 0.26f, array2[i]);
            }
        }
        private static void AddPageButtons()
        {
            int num = (buttons.Length + pageSize - 1) / pageSize;
            int num2 = pageNumber + 1;
            int num3 = pageNumber - 1;
            if (num2 > num - 1)
            {
                num2 = 0;
            }
            if (num3 < 0)
            {
                num3 = num - 1;
            }
            GameObject gameObject = GameObject.CreatePrimitive(PrimitiveType.Cube);
            UnityEngine.Object.Destroy(gameObject.GetComponent<Rigidbody>());
            gameObject.GetComponent<BoxCollider>().isTrigger = true;
            gameObject.transform.parent = menu.transform;
            gameObject.transform.rotation = Quaternion.identity;
            gameObject.transform.localScale = new Vector3(0.09f, 0.15f, 0.98f);
            gameObject.transform.localPosition = new Vector3(0.56f, 0.5833f, -0.13f);
            gameObject.AddComponent<BtnCollider>().relatedText = "PreviousPage";
            gameObject.GetComponent<Renderer>().material.SetColor("_Color", Color.black);
            gameObject.name = "back";
            gameObject.GetComponent<Renderer>().material.color = Color.black;
            GameObject gameObject2 = new GameObject();
            gameObject2.transform.parent = canvasObj.transform;
            gameObject2.name = "back";
            Text text = gameObject2.AddComponent<Text>();
            text.font = Resources.GetBuiltinResource(typeof(Font), "Arial.ttf") as Font;
            text.text = "<";
            text.fontSize = 1;
            text.alignment = TextAnchor.MiddleCenter;
            text.resizeTextForBestFit = true;
            text.resizeTextMinSize = 0;
            RectTransform component = text.GetComponent<RectTransform>();
            component.localPosition = Vector3.zero;
            component.sizeDelta = new Vector2(0.2f, 0.03f);
            component.localPosition = new Vector3(0.064f, 0.175f, -0.04f);
            component.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
            component.localScale = new Vector3(1.3f, 1.3f, 1.3f);
            GameObject gameObject3 = GameObject.CreatePrimitive(PrimitiveType.Cube);
            gameObject3.GetComponent<Renderer>().material.color = Color.black;
            UnityEngine.Object.Destroy(gameObject3.GetComponent<Rigidbody>());
            gameObject3.GetComponent<BoxCollider>().isTrigger = true;
            gameObject3.transform.parent = menu.transform;
            gameObject3.transform.rotation = Quaternion.identity;
            gameObject3.name = "Next";
            gameObject3.transform.localScale = new Vector3(0.09f, 0.15f, 0.98f);
            gameObject3.transform.localPosition = new Vector3(0.56f, -0.5833f, -0.13f);
            gameObject3.AddComponent<BtnCollider>().relatedText = "NextPage";
            gameObject3.GetComponent<Renderer>().material.SetColor("_Color", Color.black);
            GameObject gameObject4 = new GameObject();
            gameObject4.transform.parent = canvasObj.transform;
            gameObject4.name = "Next";
            Text text2 = gameObject4.AddComponent<Text>();
            text2.font = Resources.GetBuiltinResource(typeof(Font), "Arial.ttf") as Font;
            text2.text = ">";
            text2.fontSize = 1;
            text2.alignment = TextAnchor.MiddleCenter;
            text2.resizeTextForBestFit = true;
            text2.resizeTextMinSize = 0;
            RectTransform component2 = text2.GetComponent<RectTransform>();
            component2.localPosition = Vector3.zero;
            component2.sizeDelta = new Vector2(0.2f, 0.03f);
            component2.localPosition = new Vector3(0.064f, -0.175f, -0.04f);
            component2.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
            component2.localScale = new Vector3(1.3f, 1.3f, 1.3f);






            GameObject gameObject5 = GameObject.CreatePrimitive(PrimitiveType.Cube);
            gameObject5.GetComponent<Renderer>().material.color = Color.black;
            UnityEngine.Object.Destroy(gameObject5.GetComponent<Rigidbody>());
            gameObject5.GetComponent<BoxCollider>().isTrigger = true;
            gameObject5.transform.parent = menu.transform;
            gameObject5.transform.rotation = Quaternion.identity;
            gameObject5.name = "LeaveButton";
            gameObject5.transform.localScale = new Vector3(0.09f, 0.7682f, 0.075f);
            gameObject5.transform.localPosition = new Vector3(0.56f, -0.0076f, 0.5755f);
            gameObject5.AddComponent<BtnCollider>().relatedText = "Cum";
            gameObject5.GetComponent<Renderer>().material.SetColor("_Color", Color.black);
            GameObject gameObject6 = new GameObject();
            gameObject6.transform.parent = canvasObj.transform;
            gameObject6.name = "LeaveButton";
            Text text3 = gameObject6.AddComponent<Text>();
            text3.font = Resources.GetBuiltinResource(typeof(Font), "Arial.ttf") as Font;
            text3.text = "Leave";
            text3.fontSize = 1;
            text3.alignment = TextAnchor.MiddleCenter;
            text3.resizeTextForBestFit = true;
            text3.resizeTextMinSize = 0;
            RectTransform component3 = text3.GetComponent<RectTransform>();
            component3.localPosition = Vector3.zero;
            component3.sizeDelta = new Vector2(0.2f, 0.03f);
            component3.localPosition = new Vector3(0.064f, 0, 0.23f);
            component3.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
            component3.localScale = new Vector3(1f, 1f, 1f);
        }
        public static void Toggle(string relatedText)
        {
            int num = (buttons.Length + pageSize - 1) / pageSize;
            if (relatedText == "Cum")
            {
                PhotonNetwork.Disconnect();
                UnityEngine.Object.Destroy(menu);
                menu = null;
                Draw();
                return;
            }
            if (relatedText == "NextPage")
            {
                if (pageNumber < num - 1)
                {
                    pageNumber++;
                }
                else
                {
                    pageNumber = 0;
                }
                UnityEngine.Object.Destroy(menu);
                menu = null;
                Draw();
                return;
            }
            if (relatedText == "PreviousPage")
            {
                if (pageNumber > 0)
                {
                    pageNumber--;
                }
                else
                {
                    pageNumber = num - 1;
                }
                UnityEngine.Object.Destroy(menu);
                menu = null;
                Draw();
                return;
            }
            int num2 = -1;
            for (int i = 0; i < buttons.Length; i++)
            {
                if (relatedText == buttons[i])
                {
                    num2 = i;
                    break;
                }
            }
            if (buttonsActive[num2] != null)
            {
                buttonsActive[num2] = !buttonsActive[num2];
                UnityEngine.Object.Destroy(menu);
                menu = null;
                Draw();
            }
        }
        #endregion
        #region Draw2
        private static void AddButton2(float offset, string text)
        {
            GameObject gameObject = GameObject.CreatePrimitive(PrimitiveType.Cube);
            UnityEngine.Object.Destroy(gameObject.GetComponent<Rigidbody>());
            gameObject.GetComponent<BoxCollider>().isTrigger = true;
            gameObject.transform.parent = menu.transform;
            gameObject.transform.rotation = Quaternion.identity;
            gameObject.transform.localScale = new Vector3(0.09f, 0.8f, 0.08f);
            gameObject.transform.localPosition = new Vector3(0.56f, 0f, 0.58f - offset);
            gameObject.AddComponent<BtnCollider>().relatedText = text;
            gameObject.name = text;

            int num = -1;

            for (int i = 0; i < Settingsbuttons.Length; i++)
            {
                if (text == Settingsbuttons[i])
                {
                    num = i;
                    break;
                }
            }

            if (SettingsButtonsActive[num] == false)
            {
                gameObject.GetComponent<Renderer>().material.color = Color.black;
            }

            if (SettingsButtonsActive[num] == true)
            {
                gameObject.GetComponent<Renderer>().material.color = Color.red;
            }

            GameObject gameObject2 = new GameObject();
            gameObject2.transform.parent = canvasObj.transform;

            Text text2 = gameObject2.AddComponent<Text>();
            text2.font = Resources.GetBuiltinResource(typeof(Font), "Arial.ttf") as Font;
            text2.text = text;
            text2.fontSize = 1;
            text2.fontStyle = FontStyle.Italic;
            text2.alignment = TextAnchor.MiddleCenter;
            text2.resizeTextForBestFit = true;
            text2.resizeTextMinSize = 0;

            RectTransform component = text2.GetComponent<RectTransform>();
            component.localPosition = Vector3.zero;
            component.sizeDelta = new Vector2(0.2f, 0.03f);
            component.localPosition = new Vector3(0.064f, 0f, 0.231f - offset / 2.55f);
            component.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
        }
        public static void Draw2()
        {
            NumberForPage = "2";
            menu = GameObject.CreatePrimitive(PrimitiveType.Cube);
            UnityEngine.Object.Destroy(menu.GetComponent<Rigidbody>());
            UnityEngine.Object.Destroy(menu.GetComponent<BoxCollider>());
            UnityEngine.Object.Destroy(menu.GetComponent<Renderer>());
            menu.transform.localScale = new Vector3(0.1f, 0.3f, 0.4f);
            menu.name = "Menu";

            GameObject gameObject = GameObject.CreatePrimitive(PrimitiveType.Cube);
            UnityEngine.Object.Destroy(gameObject.GetComponent<Rigidbody>());
            UnityEngine.Object.Destroy(gameObject.GetComponent<BoxCollider>());
            gameObject.transform.parent = menu.transform;
            gameObject.transform.rotation = Quaternion.identity;
            gameObject.transform.localScale = new Vector3(0.1f, 0.94f, 1.2f);
            gameObject.GetComponent<Renderer>().material.SetColor("_Color", Color.black);
            gameObject.name = "Menucolor";
            gameObject.transform.position = new Vector3(0.05f, 0f, -0.03f);

            gameObject.GetComponent<Renderer>().material.color = Color.black;
            canvasObj = new GameObject();
            canvasObj.transform.parent = menu.transform;
            canvasObj.name = "canvas";

            Canvas canvas = canvasObj.AddComponent<Canvas>();
            CanvasScaler canvasScaler = canvasObj.AddComponent<CanvasScaler>();
            canvasObj.AddComponent<GraphicRaycaster>();
            canvas.renderMode = RenderMode.WorldSpace;
            canvasScaler.dynamicPixelsPerUnit = 1000f;

            GameObject gameObject2 = new GameObject();
            gameObject2.transform.parent = canvasObj.transform;
            gameObject2.name = "Title";
            Text text = gameObject2.AddComponent<Text>();
            text.font = Resources.GetBuiltinResource(typeof(Font), "Arial.ttf") as Font;
            text.text = "Settings";
            text.fontSize = 1;
            text.fontStyle = FontStyle.Italic;
            text.alignment = TextAnchor.MiddleCenter;
            text.resizeTextForBestFit = true;
            text.resizeTextMinSize = 0;
            RectTransform component = text.GetComponent<RectTransform>();
            component.localPosition = Vector3.zero;
            component.sizeDelta = new Vector2(0.28f, 0.05f);
            component.position = new Vector3(0.06f, 0f, 0.175f);
            component.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));

            AddPageSettingsbuttons2();
            string[] array2 = Settingsbuttons.Skip(pageNumber * pageSize).Take(pageSize).ToArray();
            for (int i = 0; i < array2.Length; i++)
            {
                AddButton2((float)i * 0.13f + 0.26f, array2[i]);
            }
        }
        private static void AddPageSettingsbuttons2()
        {
            int num = (Settingsbuttons.Length + pageSize - 1) / pageSize;
            int num2 = pageNumber + 1;
            int num3 = pageNumber - 1;
            if (num2 > num - 1)
            {
                num2 = 0;
            }
            if (num3 < 0)
            {
                num3 = num - 1;
            }
            GameObject gameObject = GameObject.CreatePrimitive(PrimitiveType.Cube);
            UnityEngine.Object.Destroy(gameObject.GetComponent<Rigidbody>());
            gameObject.GetComponent<BoxCollider>().isTrigger = true;
            gameObject.transform.parent = menu.transform;
            gameObject.transform.rotation = Quaternion.identity;
            gameObject.transform.localScale = new Vector3(0.09f, 0.15f, 0.98f);
            gameObject.transform.localPosition = new Vector3(0.56f, 0.5833f, -0.13f);
            gameObject.AddComponent<BtnCollider>().relatedText = "PreviousPage";
            gameObject.GetComponent<Renderer>().material.SetColor("_Color", Color.black);
            gameObject.name = "back";
            gameObject.GetComponent<Renderer>().material.color = Color.black;
            GameObject gameObject2 = new GameObject();
            gameObject2.transform.parent = canvasObj.transform;
            gameObject2.name = "back";
            Text text = gameObject2.AddComponent<Text>();
            text.font = Resources.GetBuiltinResource(typeof(Font), "Arial.ttf") as Font;
            text.text = "<";
            text.fontSize = 1;
            text.alignment = TextAnchor.MiddleCenter;
            text.resizeTextForBestFit = true;
            text.resizeTextMinSize = 0;
            RectTransform component = text.GetComponent<RectTransform>();
            component.localPosition = Vector3.zero;
            component.sizeDelta = new Vector2(0.2f, 0.03f);
            component.localPosition = new Vector3(0.064f, 0.175f, -0.04f);
            component.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
            component.localScale = new Vector3(1.3f, 1.3f, 1.3f);
            GameObject gameObject3 = GameObject.CreatePrimitive(PrimitiveType.Cube);
            gameObject3.GetComponent<Renderer>().material.color = Color.black;
            UnityEngine.Object.Destroy(gameObject3.GetComponent<Rigidbody>());
            gameObject3.GetComponent<BoxCollider>().isTrigger = true;
            gameObject3.transform.parent = menu.transform;
            gameObject3.transform.rotation = Quaternion.identity;
            gameObject3.name = "Next";
            gameObject3.transform.localScale = new Vector3(0.09f, 0.15f, 0.98f);
            gameObject3.transform.localPosition = new Vector3(0.56f, -0.5833f, -0.13f);
            gameObject3.AddComponent<BtnCollider>().relatedText = "NextPage";
            gameObject3.GetComponent<Renderer>().material.SetColor("_Color", Color.black);
            GameObject gameObject4 = new GameObject();
            gameObject4.transform.parent = canvasObj.transform;
            gameObject4.name = "Next";
            Text text2 = gameObject4.AddComponent<Text>();
            text2.font = Resources.GetBuiltinResource(typeof(Font), "Arial.ttf") as Font;
            text2.text = ">";
            text2.fontSize = 1;
            text2.alignment = TextAnchor.MiddleCenter;
            text2.resizeTextForBestFit = true;
            text2.resizeTextMinSize = 0;
            RectTransform component2 = text2.GetComponent<RectTransform>();
            component2.localPosition = Vector3.zero;
            component2.sizeDelta = new Vector2(0.2f, 0.03f);
            component2.localPosition = new Vector3(0.064f, -0.175f, -0.04f);
            component2.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
            component2.localScale = new Vector3(1.3f, 1.3f, 1.3f);


            GameObject gameObject5 = GameObject.CreatePrimitive(PrimitiveType.Cube);
            gameObject5.GetComponent<Renderer>().material.color = Color.black;
            UnityEngine.Object.Destroy(gameObject5.GetComponent<Rigidbody>());
            gameObject5.GetComponent<BoxCollider>().isTrigger = true;
            gameObject5.transform.parent = menu.transform;
            gameObject5.transform.rotation = Quaternion.identity;
            gameObject5.name = "LeaveButton";
            gameObject5.transform.localScale = new Vector3(0.09f, 0.7682f, 0.075f);
            gameObject5.transform.localPosition = new Vector3(0.56f, -0.0076f, 0.5755f);
            gameObject5.AddComponent<BtnCollider>().relatedText = "Cum";
            gameObject5.GetComponent<Renderer>().material.SetColor("_Color", Color.black);
            GameObject gameObject6 = new GameObject();
            gameObject6.transform.parent = canvasObj.transform;
            gameObject6.name = "LeaveButton";
            Text text3 = gameObject6.AddComponent<Text>();
            text3.font = Resources.GetBuiltinResource(typeof(Font), "Arial.ttf") as Font;
            text3.text = "Leave";
            text3.fontSize = 1;
            text3.alignment = TextAnchor.MiddleCenter;
            text3.resizeTextForBestFit = true;
            text3.resizeTextMinSize = 0;
            RectTransform component3 = text3.GetComponent<RectTransform>();
            component3.localPosition = Vector3.zero;
            component3.sizeDelta = new Vector2(0.2f, 0.03f);
            component3.localPosition = new Vector3(0.064f, 0, 0.23f);
            component3.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
            component3.localScale = new Vector3(1f, 1f, 1f);
        }
        public static void Toggle2(string relatedText)
        {
            int num = (Settingsbuttons.Length + pageSize - 1) / pageSize;
            if (relatedText == "Cum")
            {
                PhotonNetwork.Disconnect();
                UnityEngine.Object.Destroy(menu);
                menu = null;
                Draw2();
                return;
            }
            if (relatedText == "NextPage")
            {
                if (pageNumber < num - 1)
                {
                    pageNumber++;
                }
                else
                {
                    pageNumber = 0;
                }
                UnityEngine.Object.Destroy(menu);
                menu = null;
                Draw2();
                return;
            }
            if (relatedText == "PreviousPage")
            {
                if (pageNumber > 0)
                {
                    pageNumber--;
                }
                else
                {
                    pageNumber = num - 1;
                }
                UnityEngine.Object.Destroy(menu);
                menu = null;
                Draw2();
                return;
            }
            int num2 = -1;
            for (int i = 0; i < Settingsbuttons.Length; i++)
            {
                if (relatedText == Settingsbuttons[i])
                {
                    num2 = i;
                    break;
                }
            }
            if (SettingsButtonsActive[num2] != null)
            {
                SettingsButtonsActive[num2] = !SettingsButtonsActive[num2];
                UnityEngine.Object.Destroy(menu);
                menu = null;
                Draw2();
            }
        }
        #endregion
        #endregion
        #region Field
        public static Texture2D menutexture = new Texture2D(2, 3);
        public static GameObject fingerButtonPresser = null;
        public static GameObject MainMenuRef;
        public static bool Crash = true;
        public static int[] bones = { 4, 3, 5, 4, 19, 18, 20, 19, 3, 18, 21, 20, 22, 21, 25, 21, 29, 21, 31, 29, 27, 25, 24, 22, 6, 5, 7, 6, 10, 6, 14, 6, 16, 14, 12, 10, 9, 7 };
        internal static Coroutine freezeallCoroutine;
        public static GorillaTagManager GorillaTagManager;
        public static GorillaHuntManager GorillaHuntManager;
        public static GorillaBattleManager GorillaBattleManager;
        public static GameObject MainTextCanvas;
        public static System.Random random = new System.Random();
        public static bool rightsecondarybutton = false;
        private static bool trampolinesRestored = false;
        private static readonly RaiseEventOptions ServerCleanOptions = new RaiseEventOptions { CachingOption = EventCaching.RemoveFromRoomCache };
        private static readonly ExitGames.Client.Photon.Hashtable ServerCleanDestroyEvent = new ExitGames.Client.Photon.Hashtable();
        public static bool once = true;
        public static bool MenuLoaded = true;
        public static bool once3 = true;
        private static float SplashTime;
        private static float SnowBallTimer;
        private static float WaterBalloonTimer;
        private static float RockSpamTimer;
        private static int SpeedCount = 0;
        private static int TPSpeedCount2 = 0;
        private static int platCountType = 0;
        private static int platCountColor = 0;
        public static VRRig chosenplayer;
        public static int layers = 512;
        public static bool once2 = true;
        public static bool init = true;
        public static Vector2 rockLifetimeRange = new Vector2(5f, 10f);
        public static Vector2 rockSizeRange = new Vector2(0.5f, 2f);
        public static int framePressCooldown = 0;
        public static bool Enabled = true;
        private static float c1;
        private static bool noesp = false;
        public static GameObject C4 = null;
        private static float KickG;
        public static AnimationCurve rockMaxSizeMultiplierVsLavaProgress = AnimationCurve.Linear(0f, 1f, 1f, 1f);
        public static float aimAssistDistance = 5.0f;
        private static float TagAura;
        public static float smth = 0f;
        public static float smth2 = 0f;
        public static string NumberForPage = "1";
        private static GradientColorKey[] colorKeysPlatformMonke = new GradientColorKey[4];
        private static Vector3 scale = new Vector3(0.0125f, 0.28f, 0.3825f);
        private static Vector3? leftHandOffsetInitial = null;
        private static Vector3? rightHandOffsetInitial = null;
        private static GameObject[] jump_left_network = new GameObject[9999];
        private static GameObject[] jump_right_network = new GameObject[9999];
        public static GameObject menu = null;
        private static VRRig Tagger;
        private static bool DontDestroy = true;
        private static GameObject canvasObj = null;
        private static float a;
        private static GameObject reference = null;
        private static float ParticleSpam2;
        private static float RopeTimer;
        private static float plattype = 0f;
        private static GameObject jump_left_local = null;
        private static GameObject jump_right_local = null;
        public static GameObject pointer = null;
        private static GameObject menuObject;
        public static float reporttimer = 0f;
        public static float mastertimer = 0f;
        private static float? maxArmLengthInitial = null;
        private static float? maxJumpSpeed = null;
        private static float? jumpMultiplier = null;
        private static float Timer2;
        private static int btnCooldown = 0;
        private static int pageNumber = 0;
        private static int pageSize = 8;
        private static bool teleportGunAntiRepeat = false;
        private static bool flying = false;
        private static bool DevThing = false;
        private static bool once_left;
        private static bool once_right;
        private static bool once_left_false;
        private static bool once_right_false;
        private static bool once_networking;
        private static bool ghostToggled;
        private static float FlySpeed = 10f;
        private static float TPGunSpeed = 32f;
        public static bool TagAllTime = false;
        public static int ESpInt = 0;
        private static int BoneESpInt = 0;
        private static Color BoneESPColor = Color.white;
        private static Color ESPColor = Color.white;
        private static bool SettingsPageOn = false;
        private static Color Platcolor = Color.clear;
        public static bool[] IsTaggedSelf = new bool[10];
        public static bool[] istagged = new bool[100000];
        private static bool MainPageOn = true;
        public static Material MenuColor = new Material(Shader.Find("GorillaTag/UberShader"));
        public static Material Changer = new Material(Shader.Find("GorillaTag/UberShader"));
        public static Material BtnDisabledColor = new Material(Shader.Find("GorillaTag/UberShader"));
        public static Material BtnEnabledColor = new Material(Shader.Find("GorillaTag/UberShader"));
        public static Material Next = new Material(Shader.Find("GorillaTag/UberShader"));
        public static Material Previous = new Material(Shader.Find("GorillaTag/UberShader"));
        public static Material PointerColor = new Material(Shader.Find("GorillaTag/UberShader"));
        public static MenuPatch _instance;
        public static MenuPatch Instance
        {
            get
            {
                return _instance;
            }
        }
        #endregion 
    }
    #endregion
    #region UtilsClass
    internal class BtnCollider : MonoBehaviour
    {
        private void OnTriggerEnter(Collider collider)
        {
            if (Time.frameCount >= MenuPatch.framePressCooldown + 10)
            {
                GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(66, false, 0.1f);
                GorillaTagger.Instance.StartVibration(false, GorillaTagger.Instance.tagHapticStrength / 2, GorillaTagger.Instance.tagHapticDuration / 2);
                if (MenuPatch.NumberForPage == "1")
                {
                    MenuPatch.Toggle(this.relatedText);
                }
                else
                {
                    MenuPatch.Toggle2(this.relatedText);
                }
                MenuPatch.framePressCooldown = Time.frameCount;
            }
        }
        public string relatedText;
    }
    public class TimedBehaviour : MonoBehaviour
    {
        public virtual void Start()
        {
            this.startTime = Time.time;
        }

        public virtual void Update()
        {
            bool flag = this.complete;
            if (!flag)
            {
                this.progress = Mathf.Clamp((Time.time - this.startTime) / this.duration, 0f, 1.5f);
                bool flag2 = (double)Time.time - (double)this.startTime > (double)this.duration;
                if (flag2)
                {
                    bool flag3 = this.loop;
                    if (flag3)
                    {
                        this.OnLoop();
                    }
                    else
                    {
                        this.complete = true;
                    }
                }
            }
        }
        public virtual void OnLoop()
        {
            this.startTime = Time.time;
        }
        public bool complete = false;
        public bool loop = true;
        public float progress = 0f;
        protected bool paused = false;
        protected float startTime;
        protected float duration = 2f;
    }
    public class ColorChanger : TimedBehaviour
    {
        public override void Start()
        {
            base.Start();
            this.gameObjectRenderer = base.GetComponent<Renderer>();
        }
        public override void Update()
        {
            base.Update();
            bool flag = this.colors == null;
            if (!flag)
            {
                bool flag2 = this.timeBased;
                if (flag2)
                {
                    this.color = this.colors.Evaluate(this.progress);
                }
                this.gameObjectRenderer.material.SetColor("_Color", this.color);
                this.gameObjectRenderer.material.SetColor("_EmissionColor", this.color);
            }
        }
        public Renderer gameObjectRenderer;
        public Gradient colors = null;
        public Color color;
        public bool timeBased = true;
    }
    internal class ControllerInput : MonoBehaviour
    {
        private static bool CalculateGripState(float grabValue, float grabThreshold)
        {
            return grabValue >= grabThreshold;
        }
        public void Update()
        {
            if (ControllerInputPoller.instance != null)
            {
                ControllerInputPoller instance = ControllerInputPoller.instance;
                RightSecondary = instance.rightControllerPrimaryButton;
                RightPrimary = instance.rightControllerSecondaryButton;
                RightTrigger = CalculateGripState(instance.rightControllerIndexFloat, 0.1f);
                RightGrip = CalculateGripState(instance.rightControllerGripFloat, 0.1f);
                RightJoystick = instance.rightControllerPrimary2DAxis;
                RightStickClick = SteamVR_Actions.gorillaTag_RightJoystickClick.GetState(SteamVR_Input_Sources.RightHand);
                LeftSecondary = instance.leftControllerPrimaryButton;
                LeftPrimary = instance.leftControllerSecondaryButton;
                LeftTrigger = CalculateGripState(instance.leftControllerIndexFloat, 0.1f);
                LeftGrip = CalculateGripState(instance.leftControllerGripFloat, 0.1f);
                LeftJoystick = SteamVR_Actions.gorillaTag_LeftJoystick2DAxis.GetAxis(SteamVR_Input_Sources.LeftHand);
                LeftStickClick = SteamVR_Actions.gorillaTag_LeftJoystickClick.GetState(SteamVR_Input_Sources.LeftHand);
            }
        }
        public static bool RightSecondary;
        public static bool RightPrimary;
        public static bool RightTrigger;
        public static bool RightGrip;
        public static Vector2 RightJoystick;
        public static bool RightStickClick;
        public static bool LeftSecondary;
        public static bool LeftPrimary;
        public static bool LeftGrip;
        public static bool LeftTrigger;
        public static Vector2 LeftJoystick;
        public static bool LeftStickClick;
    }
    public class NotifiLib : BaseUnityPlugin
    {
        GameObject HUDObj;
        GameObject HUDObj2;
        GameObject MainCamera;
        Text Testtext;
        private static Text NotifiText;
        Material AlertText = new Material(Shader.Find("GUI/Text Shader"));
        int NotificationDecayTime = 300;
        int NotificationDecayTimeCounter = 0;
        string[] Notifilines;
        string newtext;
        public static string PreviousNotifi;
        bool HasInit = false;
        private static NotifiLib _instance;
        public static NotifiLib instance
        {
            get
            {
                return _instance;
            }
        }
        public void ClearAllNotifications()
        {
            NotifiText.text = "";
            Testtext.text = "";
        }
        private void Awake()
        {
            Logger.LogInfo($"Plugin NotificationLib is loaded!");
            _instance = this;
        }
        private void Init()
        {
            //this is mostly copy pasted from LHAX, which was also made by me.
            //LHAX got leaked the day before  so i might as well make this public cus people asked me to.
            MainCamera = GameObject.Find("Main Camera");
            HUDObj = new GameObject();//GameObject.CreatePrimitive(PrimitiveType.Cube);
            HUDObj2 = new GameObject();
            HUDObj2.name = "NOTIFICATIONLIB_HUD_OBJ";
            HUDObj.name = "NOTIFICATIONLIB_HUD_OBJ";
            HUDObj.AddComponent<Canvas>();
            HUDObj.AddComponent<CanvasScaler>();
            HUDObj.AddComponent<GraphicRaycaster>();
            HUDObj.GetComponent<Canvas>().enabled = true;
            HUDObj.GetComponent<Canvas>().renderMode = RenderMode.WorldSpace;
            HUDObj.GetComponent<Canvas>().worldCamera = MainCamera.GetComponent<Camera>();
            HUDObj.GetComponent<RectTransform>().sizeDelta = new Vector2(5, 5);
            //HUDObj.CreatePrimitive()
            HUDObj.GetComponent<RectTransform>().position = new Vector3(MainCamera.transform.position.x, MainCamera.transform.position.y, MainCamera.transform.position.z);//new Vector3(-67.151f, 11.914f, -82.749f);
            HUDObj2.transform.position = new Vector3(MainCamera.transform.position.x, MainCamera.transform.position.y, MainCamera.transform.position.z - 4.6f);
            HUDObj.transform.parent = HUDObj2.transform;
            HUDObj.GetComponent<RectTransform>().localPosition = new Vector3(0f, 0f, 1.6f);
            var Temp = HUDObj.GetComponent<RectTransform>().rotation.eulerAngles;
            Temp.y = -270f;
            HUDObj.transform.localScale = new Vector3(1f, 1f, 1f);
            HUDObj.GetComponent<RectTransform>().rotation = Quaternion.Euler(Temp);
            GameObject TestText = new GameObject();
            TestText.transform.parent = HUDObj.transform;
            Testtext = TestText.AddComponent<Text>();
            Testtext.text = "";
            Testtext.fontSize = 10;
            Testtext.font = GameObject.Find("COC Text").GetComponent<Text>().font;
            Testtext.rectTransform.sizeDelta = new Vector2(260, 70);
            Testtext.alignment = TextAnchor.LowerLeft;
            Testtext.rectTransform.localScale = new Vector3(0.01f, 0.01f, 1f);
            Testtext.rectTransform.localPosition = new Vector3(-1.5f, -.9f, -.6f);
            Testtext.material = AlertText;
            NotifiText = Testtext;
        }
        public void FixedUpdate()
        {
            try
            {
                if (!HasInit)
                {
                    if (GameObject.Find("Main Camera") != null)
                    {
                        Init();
                        HasInit = true;
                    }
                }
                if (HasInit)
                {
                    HUDObj2.transform.position = new Vector3(MainCamera.transform.position.x, MainCamera.transform.position.y, MainCamera.transform.position.z);
                    HUDObj2.transform.rotation = MainCamera.transform.rotation;
                    if (Testtext.text != "")
                    {
                        NotificationDecayTimeCounter++;
                        if (NotificationDecayTimeCounter > NotificationDecayTime)
                        {
                            Notifilines = null;
                            newtext = "";
                            NotificationDecayTimeCounter = 0;
                            Notifilines = Testtext.text.Split(Environment.NewLine.ToCharArray()).Skip(1).ToArray<string>();
                            foreach (string text in Notifilines)
                            {
                                if (text != "")
                                {
                                    newtext = newtext + text + "\n";
                                }
                            }
                            Testtext.text = newtext;
                        }
                    }
                    else
                    {
                        NotificationDecayTimeCounter = 0;
                    }
                }
            }
            catch (Exception message)
            {
                Debug.LogError(message);
                throw;
            }
        }
        public static string LestNotifif = "";
        public static void SendNotification(string notificationText, Color textColor)
        {
            try
            {
                GameObject thing = GameObject.Find("NOTIFICATIONLIB_HUD_OBJ/NOTIFICATIONLIB_HUD_OBJ");
                if (!notificationText.Contains(Environment.NewLine))
                {
                    notificationText = notificationText + Environment.NewLine;
                    if (thing.transform.GetChild(0).GetComponent<Text>().text != notificationText)
                    {
                        Text textComponent = thing.transform.GetChild(0).GetComponent<Text>();
                        textComponent.text = notificationText;
                        textComponent.color = textColor;
                        PreviousNotifi = notificationText;
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
                MenuPatch.Mods.Utils.LogError(ex);
            }
        }
    }
    #endregion
}