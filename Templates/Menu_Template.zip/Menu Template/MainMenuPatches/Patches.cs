﻿using HarmonyPatch = HarmonyLib.HarmonyPatch;
using BepInEx;
using GorillaLocomotion;
using HarmonyLib;
using NIKO_Menu.MainMenu;
using Photon.Pun;
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using UnityEngine;

namespace Menu_Temp.MainMenuPatches
{
    #region Patches
    [BepInPlugin("NIKOMods.Patches", "Patches", "1.0.0")]
    public class Patches : MonoBehaviour
    {
        private void Awake()
        {
            Debug.Log("Patches Activated!");
            NotifiLib.SendNotification("Patches Activated!", Color.green);
        }
        #region UpdateLine Patch
        [HarmonyLib.HarmonyPatch(typeof(GorillaPlayerScoreboardLine))]
        [HarmonyLib.HarmonyPatch("UpdateLine", MethodType.Enumerator)]
        public class UpdateLine
        {
            public static bool Prefix()
            {
                return Override;
            }
            public static bool Override = true;
        }
        #endregion
        #region VRRigOnDisable Patch
        [HarmonyPatch(typeof(VRRig))]
        [HarmonyPatch("OnDisable", MethodType.Normal)]
        public class VRRigOnDisable
        {
            public static bool Prefix(VRRig __instance)
            {
                if (__instance == GorillaTagger.Instance.offlineVRRig)
                {
                    VRRig offlineVRRig = GorillaTagger.Instance.offlineVRRig;
                    typeof(VRRig).GetField("initialized", BindingFlags.Instance | BindingFlags.NonPublic).SetValue(offlineVRRig, false);
                    typeof(VRRig).GetField("voiceAudio", BindingFlags.Instance | BindingFlags.NonPublic).SetValue(offlineVRRig, null);
                    typeof(VRRig).GetField("tempRig", BindingFlags.Instance | BindingFlags.NonPublic).SetValue(offlineVRRig, null);
                    typeof(VRRig).GetField("timeSpawned", BindingFlags.Instance | BindingFlags.NonPublic).SetValue(offlineVRRig, 0);
                    typeof(VRRig).GetField("creator", BindingFlags.Instance | BindingFlags.NonPublic).SetValue(offlineVRRig, null);
                    __instance.muted = false;
                    __instance.initializedCosmetics = false;
                    return false;
                }
                return true;
            }
        }
        #endregion
    }
    #endregion
}