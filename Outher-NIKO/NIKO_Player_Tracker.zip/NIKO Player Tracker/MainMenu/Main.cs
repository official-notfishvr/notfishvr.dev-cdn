﻿using Debug = UnityEngine.Debug;
using Random = UnityEngine.Random;
using Color = UnityEngine.Color;
using Object = UnityEngine.Object;
using Hashtable = ExitGames.Client.Photon.Hashtable;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using ExitGames.Client.Photon;
using HarmonyLib;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine;
using UnityEngine.UI;
using Valve.VR;
using GorillaLocomotion.Gameplay;
using GorillaLocomotion.Swimming;
using System.Net;
using System.Diagnostics;
using GorillaNetworking;
using Photon.Voice.Unity;
using Photon.Voice.Unity.UtilityScripts;
using System.Collections;
using BepInEx;
using GorillaTag;
using System.Collections.Specialized;
using Newtonsoft.Json;
using System.ComponentModel;
using System.Reflection;
using UnityEngine.InputSystem;
using System.Threading.Tasks;
using static OVRPlugin;

namespace NIKO_Menu.MainMenu
{
    #region Loader
    [BepInPlugin("com.notfishvr.nikomenu", "notfishvr", "1.0.0")]
    public class Loader : BaseUnityPlugin
    {
        public void FixedUpdate()
        {
            if (!GameObject.Find("Loader") && GorillaLocomotion.Player.hasInstance)
            {
                GameObject Loader = new GameObject("Loader");
                Loader.AddComponent<ControllerInput>();
                Loader.AddComponent<PlayerTracker>();
                Loader.AddComponent<RigManager>();
            }
        }
    }
    #endregion
    #region HarmonyPatch
    [BepInPlugin("NIKO.Menu", "NIKO.Menu", "1.0.0")]
    [Description("NIKO.Menu")]
    public class HarmonyPatch : BaseUnityPlugin
    {
        public void Awake()
        {
            Harmony harmony = new Harmony("NIKO.Menu");
            harmony.PatchAll(Assembly.GetExecutingAssembly());
        }
        private const string modGUID = "NIKO.Menu";
        private const string modName = "NIKO.Menu";
        public const string modVersion = "1.0.0";
    }
    #endregion
    #region PlayerTracker
    public class PlayerTracker : MonoBehaviourPunCallbacks
    {
        public static PlayerTracker Instance { get; private set; }

        private readonly Dictionary<string, string> userActions = new Dictionary<string, string>
        {
            { "1DB36338244FB25B", "shadow2410" },
            { "F8029EAA2E473447", "Kid Who Waana To Bee On This" },
            { "7FB16B1EDEB71A4C", "Elliot" },
            { "A6FFC7318E1301AF", "JMAN" },
            { "1D6E20BE9655C798", "TTTpig" },
            { "CBCCBBB6C28A94CF", "PTMstar" },
            { "42C809327652ECDD", "ElectronicWall" },
            { "AAB44BFD0BA34829", "Boda" },
            { "80279945E7D3B57D", "Jolyne" },
            { "7E44E8337DF02CC1", "Nunya" },
            { "DE601BC40DB68CE0", "Graic" },
            { "2E408ED946D55D51", "StickyStuck" },
            { "D0CB396539676DD8", "FrogIlla" },
            { "6F79BE7CB34642AC", "CodyOQuinn" },
            { "F5B5C64914C13B83", "HatGirl" },
            { "10D31D3BDCCE5B1F", "DeezeyQuest" },
            { "636D8846E76C9B5A", "Clown" },
            { "ECDE8A2FF8510934", "Antoca" },
            { "E354E818871BD1D8", "DevTheyThem" },
            { "9DBC90CF7449EF64", "StyledSnail" },
            { "6713DA80D2E9BFB5", "HauntedArmy" },
            { "28EA953654FF2E79", "TTTkovu" },
            { "8BD18B93D4296118", "ITZJF9000" },
            { "3B9FD2EEF24ACB3", "VMT" },
            { "33FFA45DBFD33B01", "Will" },
            { "3D1FE1697EAB3EA1", "DeepVR" },
            { "3A141200E3A60FF1", "UncleRon" },
            { "6698C4A2CE231610", "EyeRock" },
            { "7FB16B1EDEB71A4C", "Elloitt" },
            { "571776944B6162F1", "CubCub" },
            { "7COCA38E86ED08B", "ElliotAlt" },
            { "BC99FA914F506AB8", "LEMMING THE CREATOR OF GTAG" },
            { "D6971CA01F82A975", "ELLIOT PC" },
            { "378D7E14A11734FF", "ERIK1515" },
            { "AAE89F1B3E359257", "ERIK1515 2" },
            { "A6FFC7318E1301AF", "JMANCURLY" }
        };

        private bool trackerOn;
        public string Room = "";
        public string LastMsg = "";

        private void OnGUI()
        {
            Room = GUI.TextArea(new Rect(10f, 40f, 100f, 20f), Room);
            if (GUI.Button(new Rect(10f, 60f, 100f, 20f), "Join Room"))
            {
                PhotonNetwork.JoinRoom(Room);
            }

            trackerOn = GUI.Toggle(new Rect(10f, 100f, 100f, 20f), trackerOn, "Turn On Player Tracker");
            if (!trackerOn)
            {
                trackerOn = GUI.Toggle(new Rect(10f, 120f, 100f, 20f), trackerOn, "Turn Off Player Tracker");
            }
        }

        private void Awake()
        {
            Instance = this;
            SendWebhook("Started Tracker");
        }

        private void Update()
        {
            if (trackerOn)
            {
                UpdateLogic();
            }
            else
            {

            }
        }

        private async Task UpdateLogic()
        {
            if (!PhotonNetwork.IsConnectedAndReady)
            {
                await Task.Delay(1000);
            }
            else if (!PhotonNetwork.InRoom)
            {
                PhotonNetwork.JoinRandomRoom();
            }
            else
            {
                bool foundPlayer = false;
                foreach (Player player in PhotonNetwork.PlayerList)
                {
                    if (userActions.TryGetValue(player.UserId, out string playerName))
                    {
                        SendWebhook($"Found Player: {player.UserId}/{playerName} in room {PhotonNetwork.CurrentRoom.Name} with nickname: {player.NickName}");
                        await Task.Delay(1000);
                        foundPlayer = true;
                    }
                }

                if (!foundPlayer)
                {
                    await Task.Delay(1000);
                    PhotonNetwork.Disconnect();
                }
            }
        }
        public void SendWebhook(string message)
        {
            try
            {
                if (LastMsg != message)
                {
                    NameValueCollection data = new NameValueCollection { { "content", message } };
                    using WebClient webClient = new WebClient();
                    webClient.UploadValues("put webhook here", "POST", data);
                    LastMsg = message;
                }
                if (LastMsg == message)
                {
                    PhotonNetwork.Disconnect();
                }
            }
            catch (WebException ex)
            {
                Debug.Log(ex.Message);
            }
        }
    }
    #endregion
    #region UtilsClass
    public class TimedBehaviour : MonoBehaviour
    {
        public virtual void Start()
        {
            startTime = Time.time;
        }

        public virtual void Update()
        {
            bool flag = complete;
            if (!flag)
            {
                progress = Mathf.Clamp((Time.time - startTime) / duration, 0f, 1.5f);
                bool flag2 = (double)Time.time - (double)startTime > (double)duration;
                if (flag2)
                {
                    bool flag3 = loop;
                    if (flag3)
                    {
                        OnLoop();
                    }
                    else
                    {
                        complete = true;
                    }
                }
            }
        }
        public virtual void OnLoop()
        {
            startTime = Time.time;
        }
        public bool complete = false;
        public bool loop = true;
        public float progress = 0f;
        protected bool paused = false;
        protected float startTime;
        protected float duration = 2f;
    }
    public class ColorChanger : TimedBehaviour
    {
        public override void Start()
        {
            base.Start();
            gameObjectRenderer = base.GetComponent<Renderer>();
        }
        public override void Update()
        {
            base.Update();
            bool flag = colors == null;
            if (!flag)
            {
                bool flag2 = timeBased;
                if (flag2)
                {
                    color = colors.Evaluate(progress);
                }
                gameObjectRenderer.material.SetColor("_Color", color);
                gameObjectRenderer.material.SetColor("_EmissionColor", color);
            }
        }
        public Renderer gameObjectRenderer;
        public Gradient colors = null;
        public Color color;
        public bool timeBased = true;
    }
    internal class ControllerInput : MonoBehaviour
    {
        private static bool CalculateGripState(float grabValue, float grabThreshold)
        {
            return grabValue >= grabThreshold;
        }
        public void Update()
        {
            if (ControllerInputPoller.instance != null)
            {
                ControllerInputPoller instance = ControllerInputPoller.instance;
                RightSecondary = instance.rightControllerPrimaryButton;
                RightPrimary = instance.rightControllerSecondaryButton;
                RightTrigger = CalculateGripState(instance.rightControllerIndexFloat, 0.1f);
                RightGrip = CalculateGripState(instance.rightControllerGripFloat, 0.1f);
                RightJoystick = instance.rightControllerPrimary2DAxis;
                RightStickClick = SteamVR_Actions.gorillaTag_RightJoystickClick.GetState(SteamVR_Input_Sources.RightHand);
                LeftSecondary = instance.leftControllerPrimaryButton;
                LeftPrimary = instance.leftControllerSecondaryButton;
                LeftTrigger = CalculateGripState(instance.leftControllerIndexFloat, 0.1f);
                LeftGrip = CalculateGripState(instance.leftControllerGripFloat, 0.1f);
                LeftJoystick = SteamVR_Actions.gorillaTag_LeftJoystick2DAxis.GetAxis(SteamVR_Input_Sources.LeftHand);
                LeftStickClick = SteamVR_Actions.gorillaTag_LeftJoystickClick.GetState(SteamVR_Input_Sources.LeftHand);
            }
        }
        public static bool RightSecondary;
        public static bool RightPrimary;
        public static bool RightTrigger;
        public static bool RightGrip;
        public static Vector2 RightJoystick;
        public static bool RightStickClick;
        public static bool LeftSecondary;
        public static bool LeftPrimary;
        public static bool LeftGrip;
        public static bool LeftTrigger;
        public static Vector2 LeftJoystick;
        public static bool LeftStickClick;
    }
    internal class RigManager : BaseUnityPlugin
    {
        internal static VRRig GetOfflineRig()
        {
            return GorillaTagger.Instance.offlineVRRig;
        }
        internal static VRRig FindRig(Photon.Realtime.Player player)
        {
            return GorillaGameManager.instance.FindPlayerVRRig(player);
        }
        internal static PhotonView GetRigView(VRRig rig)
        {
            return (PhotonView)Traverse.Create(rig).Field("photonView").GetValue();
        }
        internal static PhotonView MyView()
        {
            return GorillaTagger.Instance.myVRRig;
        }
    }
    #endregion
}