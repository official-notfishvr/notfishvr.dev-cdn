using NIKO_Menu.MainMenu;
using System.Diagnostics;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

[assembly: AssemblyProduct("NIKO Mod Menu")]
[assembly: AssemblyTitle("NIKO Mod Menu")]
[assembly: AssemblyDescription("This Is NIKO Mod Menu\rMade By discord.gg/nikomods/notfishvr")]

[assembly: AssemblyCompany("NIKO Mods")]
[assembly: AssemblyCopyright("Copyright � 2023 NIKO Mods")]
[assembly: AssemblyConfiguration("Release")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: ComVisible(false)]
[assembly: AssemblyCulture("en-US")]
[assembly: NeutralResourcesLanguage("en-US")]
[assembly: AssemblyInformationalVersion("1.0")]
[assembly: AssemblyTrademark("NIKO Mods")]